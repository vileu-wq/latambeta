---
trigger: always_on
description: Workspace rules and domain context for the Odoo Mexico & LATAM Knowledge Hub
---

# Odoo LATAM Knowledge Hub — Workspace Directives

## 1. Domain & Purpose
You are developing the **Odoo Mexico & LATAM Knowledge Hub**, a standalone, client-side reference application designed for Odoo functional consultants and support engineers handling Mexican SAT e-invoicing and Latin American fiscal localizations.

## 2. Technical Stack & Architecture
- **Single-File Architecture**: The core application resides in `index.html`.
- **Zero Server Runtime**: Pure HTML5, Tailwind CSS via CDN, and Vanilla JavaScript. No Node.js build process or backend dependencies.
- **Branding Colors**:
  - Official Odoo Purple / Aubergine: `#714B67` (Hover: `#5A3A52`, Text: `#4A2C43`)
  - Enterprise Teal: `#00A09D` (Hover: `#008481`)
  - Warning / Alert Amber: Background `#FDE68A`, Text `#78350F`, Border `#D98324`
- **Typography & UI**: Font family `Inter`, smooth rounded cards (`rounded-xl` / `rounded-2xl`), accessible hover previews with fixed popover positioning and zero-clipping overflow.

## 3. Strict User Directives (Do Not Alter Without User Request)
1. **Flow Scope**: The procedure applies specifically when **1 payment pays for the entirety of 1 invoice** (PPD without bank reconciliation). Tag copy: `1 Payment Pays Entirety of 1 Invoice`.
2. **Overview Prerequisite**: Must highlight and underline: `<u ...><mark ...>you must have configured incoming and outgoing payments in your bank journal</mark></u>`.
3. **Internal Support Protocol**: Must strictly use this phrasing:
   *"Clients should check their SAT portal; if it's approved in their SAT portal but not in Odoo, they must contact us via ticket to rectify records in Odoo."*
4. **Simplified Terminology**: Always use "Stamp Payment" / "Stamped Payment Receipt" instead of "Stamp REP 2.0".
5. **External Resource Links**: The Payment Complement card must maintain both:
   - Official Documentation: `https://www.odoo.com/documentation/17.0/applications/finance/fiscal_localizations/mexico.html#receipt-of-payments`
   - Odoo Community Forum results: `https://www.odoo.com/es_ES/forum/ayuda-1?sorting=last_activity_date+desc&search=complemento+de+pago+sin+conciliacion+&filters=all`
6. **Multi-Location Sync**: Always keep all mirror files and backup copies synchronized with identical SHA-256 checksums.
